create definer = `mariadb.sys`@localhost view privileges_by_table_by_level as
select `t`.`TABLE_SCHEMA`       AS `TABLE_SCHEMA`,
       `t`.`TABLE_NAME`         AS `TABLE_NAME`,
       `privs`.`GRANTEE`        AS `GRANTEE`,
       `privs`.`PRIVILEGE_TYPE` AS `PRIVILEGE`,
       `privs`.`LEVEL`          AS `LEVEL`
from (`INFORMATION_SCHEMA`.`TABLES` `t` join (select NULL                                                    AS `TABLE_SCHEMA`,
                                                     NULL                                                    AS `TABLE_NAME`,
                                                     `information_schema`.`USER_PRIVILEGES`.`GRANTEE`        AS `GRANTEE`,
                                                     `information_schema`.`USER_PRIVILEGES`.`PRIVILEGE_TYPE` AS `PRIVILEGE_TYPE`,
                                                     'GLOBAL'                                                AS `LEVEL`
                                              from `INFORMATION_SCHEMA`.`USER_PRIVILEGES`
                                              union
                                              select `information_schema`.`SCHEMA_PRIVILEGES`.`TABLE_SCHEMA`   AS `TABLE_SCHEMA`,
                                                     NULL                                                      AS `TABLE_NAME`,
                                                     `information_schema`.`SCHEMA_PRIVILEGES`.`GRANTEE`        AS `GRANTEE`,
                                                     `information_schema`.`SCHEMA_PRIVILEGES`.`PRIVILEGE_TYPE` AS `PRIVILEGE_TYPE`,
                                                     'SCHEMA'                                                  AS `LEVEL`
                                              from `INFORMATION_SCHEMA`.`SCHEMA_PRIVILEGES`
                                              union
                                              select `information_schema`.`TABLE_PRIVILEGES`.`TABLE_SCHEMA`   AS `TABLE_SCHEMA`,
                                                     `information_schema`.`TABLE_PRIVILEGES`.`TABLE_NAME`     AS `TABLE_NAME`,
                                                     `information_schema`.`TABLE_PRIVILEGES`.`GRANTEE`        AS `GRANTEE`,
                                                     `information_schema`.`TABLE_PRIVILEGES`.`PRIVILEGE_TYPE` AS `PRIVILEGE_TYPE`,
                                                     'TABLE'                                                  AS `LEVEL`
                                              from `INFORMATION_SCHEMA`.`TABLE_PRIVILEGES`) `privs`
      on ((`t`.`TABLE_SCHEMA` = `privs`.`TABLE_SCHEMA` or `privs`.`TABLE_SCHEMA` is null) and
          (`t`.`TABLE_NAME` = `privs`.`TABLE_NAME` or `privs`.`TABLE_NAME` is null) and `privs`.`PRIVILEGE_TYPE` in
                                                                                        ('SELECT', 'INSERT', 'UPDATE',
                                                                                         'DELETE', 'CREATE', 'ALTER',
                                                                                         'DROP', 'INDEX', 'REFERENCES',
                                                                                         'TRIGGER', 'GRANT OPTION',
                                                                                         'SHOW VIEW',
                                                                                         'DELETE HISTORY')))
where `t`.`TABLE_SCHEMA` not in ('sys', 'mysql', 'information_schema', 'performance_schema');

